﻿=== Pizza Cursor Set ===

By: MintPepper (http://www.rw-designer.com/user/61590)

Download: http://www.rw-designer.com/cursor-set/pizza-4

Author's description:

Delicious cursor for your computer!

These cursors will make you hungry everytime you use your computer

(CAUTION: DO NOT EAT)

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.